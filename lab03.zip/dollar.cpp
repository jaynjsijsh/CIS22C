/*
* Lab 3
* Harmony Trinh and Jayne Tan
* The purpose of this lab is to implement and demonstrate link-based ADTs to store Currency objects and perform different operations on these data structures
*/
#include <iostream>
#include <string>
#include "Currency.cpp"
//removed using namespace std;

class Dollar : public Currency {
protected:
    std::string type = "Dollar";
    std::string get_type() {
        return type;
    }
public:
    //constructors
    Dollar() : Currency() {  }
    Dollar(double value) : Currency(value) { }
    Dollar(Dollar& currncy) : Currency(currncy) { }
};